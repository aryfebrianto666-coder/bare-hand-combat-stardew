Bare-Hand Combat Android — SOURCE DEVELOPMENT KIT (v0.2.0-dev)

Status: BELUM SIAP DIPASANG. Tidak ada DLL hasil kompilasi di paket ini.
Kode ini belum dikompilasi atau diuji pada Stardew Valley Android 1.6.15 build 24354 / SMAPI Android 1.1.4.

Target yang diminta:
- Tombol PUNCH di HUD untuk layar sentuh.
- Damage 20 per pukulan.
- Menarget monster yang dekat dan berada di arah hadap pemain.
- Efek suara dan sprite benturan sederhana.

Batasan penting:
- Posisi tombol, pemetaan sentuhan ke SButton.MouseLeft, API takeDamage, dan efek sprite harus dikompilasi dan diuji di game yang sebenarnya.
- Paket ini adalah SOURCE, bukan folder mod siap pakai. Jangan salin langsung ke Mods dan berharap mod berjalan.
- Build C# SMAPI umumnya memakai .NET 6 dan Pathoschild.Stardew.ModBuildConfig. Build config memerlukan referensi instalasi game yang sesuai; pipeline build berbasis cloud tanpa file game/reference assembly belum disediakan di paket ini.
- Jika build gagal, kirim teks error kompilasi lengkap agar sumber bisa diperbaiki.

Instalasi setelah build berhasil:
1. Kompilasi proyek src/BareHandCombatAndroid.csproj menggunakan .NET 6 SDK dan referensi game/SMAPI yang cocok.
2. Pastikan hasil BareHandCombatAndroid.dll berada di folder yang sama dengan manifest.json.
3. Salin folder hasil build ke:
   /storage/emulated/0/Android/data/abc.smapi.gameloader/files/Mods/BareHandCombatAndroid/
4. Jalankan SMAPI dan kirim log baru. Jangan anggap berhasil sebelum SMAPI memuat DLL dan tombol diuji di dalam game.

Versi berdasarkan log pengguna:
- Stardew Valley 1.6.15 build 24354
- SMAPI 4.3.2.5
- Launcher 1.1.4
